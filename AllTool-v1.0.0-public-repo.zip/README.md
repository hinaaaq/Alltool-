# AllTool

**An all-in-one Android utility toolkit focused on practical tools and offline-first functionality.**

AllTool brings supported image and document utilities together in one Android app. Processing is performed on-device where supported.

## Current release

The repository is being prepared for its first public release, **v1.0.0**. This is a version-number reset for the public release; the included source originated from the previous development line. Review the limitations below before treating it as a stable release.

## Current capabilities

- Image editing and background segmentation using on-device processing.
- Manual object-retouch approximation for small objects and simpler backgrounds; results can vary and this is not generative AI.
- Document image filters and local PDF/DOCX export where supported by the current source.
- Image quality and memory options intended to reduce peak RAM use.

Feature availability and behavior depend on the included source and device. See the source README and test the app before distributing it.

## Build with GitHub Actions

1. Upload the repository contents to GitHub.
2. Open **Actions → Build AllTool APK**.
3. Select **Run workflow**.
4. Download the `AllTool-v1.0.0-debug-APK` artifact after the workflow succeeds.

The workflow builds a **debug APK for testing**, not a signed production release.

## Local build

Requirements: JDK 17 and Android SDK Platform 35 / Build Tools 35.0.0. Extract `AllTool-source.zip`, enter the directory containing `settings.gradle.kts`, then run:

```bash
gradle :app:assembleDebug
```

The generated APK is under `app/build/outputs/apk/debug/`.

## Privacy

The app is designed to perform supported image processing locally. Review Android permissions, dependencies, and network behavior in the source before relying on any privacy claim.

## Contributing

Bug reports and improvement suggestions are welcome. Include the device model, Android version, steps to reproduce, and relevant logs. Never post passwords, signing keys, tokens, or private images in issues.

## License

No project license has been selected yet. Until a license is added, do not assume the source is licensed for reuse, modification, or redistribution. Third-party dependencies remain subject to their own licenses.

## Maintainer

Hina / Yasin — [@hinaaqq](https://github.com/hinaaqq)
