# v1.0.0 release checklist

- [ ] Run GitHub Actions and confirm a successful build.
- [ ] Install and test the APK on at least one physical Android device.
- [ ] Verify image selection, processing, export, document tools, and settings.
- [ ] Check app permissions and third-party dependency licenses.
- [ ] Decide and add a project license before inviting code reuse.
- [ ] Create a signed release APK/AAB before calling it a production release.
- [ ] Add release notes describing known limitations.
